const {UserModel} = require('../../../db/index');
const {GenealogyTree, GenealogyOrder} = require('../../../db/index');
class genealogyController {
    getUsers(req, res) {
        try{
            UserModel.find({}).then(users => {
                res.status(200).json(users);
            });
        }
        catch (e) {
            res.status(500).send(e);
        }
    }
    createOrder(req, res) {
        try {
            let products = [{}];
            products =  JSON.parse(req.body.products);
            for (let i = 0; i < products.length; i++) {
                const genealogyOrder = new GenealogyOrder ({
                    starter_id: products[i].starter_id,
                    consumer_id: products[i].consumer_id,
                    seller_id: products[i].seller_id,
                    product_id: products[i].product_id,
                    qty: products[i].qty
                });
                genealogyOrder.save();
            }
            res.send({status: true, msg: 'Successfully created'});
        }catch (e) {
            res.status(500).send(e);
        }
    }
    initTree(req, res) {
        try{
            if(req.body) {
                const tree = new GenealogyTree({
                    user_id: req.body.tree.id,
                    upper_id: 0,
                    position: 'origin',
                    seller_id: 0,
                    starter_id: 0,
                    status: 'pass'
                });
                tree.save().then(data=> {
                    res.send({status:'success',code: 201, data: data});
                });
            }
        }catch (e) {
            res.send(e);
        }
    }
    getUsersFromTree(req, res) {
        try{
            GenealogyTree.find({}).then(data => {res.send(data)})
        }catch (e) {
            res.send(e);
        }
    }
    getUsersFromTreeByStarter(req, res) {
        try{
            console.log('here in gene controller>>>>>>>>>>>>>>>>', req.query.starter_id)
            GenealogyTree.find({starter_id: req.query.starter_id}).then(data => {
                console.log('here in cont data>>>>>>>>>>>', data);
                res.json(data);
            })
        }catch (e) {
            res.send(e);
        }
    }
    createTree(req, res) {
        try{
            const genealogyTree = new GenealogyTree({
                user_id: req.body.data[0]['user_id'],
                upper_id: req.body.data[0]['upper_id'],
                position: req.body.data[0]['position'],
                seller_id: req.body.data[0]['seller_id'],
                starter_id: req.body.data[0]['starter_id']
            });
            genealogyTree.save().then(user_to_tree => {
                res.status(201).send(user_to_tree);
            });
        }catch (e) {
            res.status(500).send(e);
        }
    }
}

module.exports = new genealogyController();
