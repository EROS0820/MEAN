const {GenealogyOrder, BinarySeller}  = require('../../../db/index')
class preOrderController {
    getPreOrder(req, res) {
        const userid = req.query.userid;
        console.log('I am here in pre order controller>>>>>>>>>>', userid)
        GenealogyOrder.find({starter_id: userid, status: 'ordered'}).then(
            preOrder => { console.log(preOrder, 'this is result>>>>>>>>>>>>>'); res.json(preOrder)}
        )
    }
}
module.exports = new preOrderController();
