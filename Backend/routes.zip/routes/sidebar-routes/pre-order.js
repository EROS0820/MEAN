const {Router} = require('express');
const preOrderController = require('../controllers/sidebar-controller/pre-order.controller');
const router = Router();
router.get('/getPreOrder', preOrderController.getPreOrder);
module.exports = router;
