import { BalancetypePipe } from './balancetype.pipe';

describe('BalancetypePipe', () => {
  it('create an instance', () => {
    const pipe = new BalancetypePipe();
    expect(pipe).toBeTruthy();
  });
});
