import { Component, OnInit, ViewChild } from '@angular/core';

import { MatDialog, MatTable } from '@angular/material';
import { DialogBoxComponent } from './dialog-box/dialog-box.component';
import {StorageService} from "../../services/storage.service";
import {PreOrderService} from "../../services/side_services/pre-order.service";

export interface UsersData {
  name: string;
  id: number;
}

const ELEMENT_DATA: UsersData[] = [
  {id: 1560608769632, name: 'Artificial Intelligence'},
  {id: 1560608796014, name: 'Machine Learning'},
  {id: 1560608787815, name: 'Robotic Process Automation'},
  {id: 1560608805101, name: 'Blockchain'}
];


@Component({
  selector: 'app-pre-order',
  templateUrl: './pre-order.component.html',
  styleUrls: ['./pre-order.component.css']
})
export class PreOrderComponent implements OnInit {

  displayedColumns: string[] = ['id', 'name', 'action'];
  dataSource = ELEMENT_DATA;
  currentUser: any;
  @ViewChild(MatTable) table: MatTable<any>;


  constructor(public dialog: MatDialog,
              private storageService: StorageService,
              private preOrderService: PreOrderService,

              ) {
    this.currentUser =  this.storageService.getUser()
  }

  ngOnInit() {
    console.log('start pre order>>>>>>>>>>>>>>>1');
    this.initAll();
    console.log('start pre order>>>>>>>>>>>>>>>2');
  }

  openDialog(action,obj) {
    obj.action = action;
    const dialogRef = this.dialog.open(DialogBoxComponent, {
      width: '250px',
      data:obj
    });

    dialogRef.afterClosed().subscribe(result => {
      if(result.event == 'Add'){
        this.addRowData(result.data);
      }else if(result.event == 'Update'){
        this.updateRowData(result.data);
      }else if(result.event == 'Delete'){
        this.deleteRowData(result.data);
      }
    });
  }

  addRowData(row_obj){
    var d = new Date();
    this.dataSource.push({
      id:d.getTime(),
      name:row_obj.name
    });
    this.table.renderRows();

  }
  updateRowData(row_obj){
    this.dataSource = this.dataSource.filter((value,key)=>{
      if(value.id == row_obj.id){
        value.name = row_obj.name;
      }
      return true;
    });
  }
  deleteRowData(row_obj){
    this.dataSource = this.dataSource.filter((value,key)=>{
      return value.id != row_obj.id;
    });
  }

  initAll() {
    this.getPreOrder();
  }
  getPreOrder() {
    return this.preOrderService.getPreOrder(this.currentUser['id'])
      .pipe().subscribe(res => {console.log('here component>>>>>>>>>', res);return res;});
  }
}
