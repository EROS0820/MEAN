import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-indirect-savings',
  templateUrl: './indirect-savings.component.html',
  styleUrls: ['./indirect-savings.component.css']
})
export class IndirectSavingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
