import { TxtypePipe } from './txtype.pipe';

describe('TxtypePipe', () => {
  it('create an instance', () => {
    const pipe = new TxtypePipe();
    expect(pipe).toBeTruthy();
  });
});
