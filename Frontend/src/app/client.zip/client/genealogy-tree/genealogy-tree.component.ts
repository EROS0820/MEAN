import { Component, OnInit } from '@angular/core';
import {StorageService} from "../../services/storage.service";
import {first, map} from "rxjs/operators";
import {BinarySellerService} from "../../services/side_services/binary-seller.service";
import {environment} from "../../../environments/environment";
import {GenealogyTreeService} from "../../services/side_services/genealogy-tree.service";
import {CountryCurrencyPriceService} from "../../services/country-currency-price.service";
import Currency from "../../model/currency";
import {HttpService} from "../../services/http.service";
import {ShareService} from "../../services/share.service";

@Component({
  selector: 'app-genealogy-tree',
  templateUrl: './genealogy-tree.component.html',
  styleUrls: ['./genealogy-tree.component.css']
})
export class GenealogyTreeComponent implements OnInit {
  userInfo: any;
  currency: Currency = new Currency;
  cCode = 'PH';
  curCode = 'PHP';
  currencyValue = 0;
  products:any = [];
  currentUser = [];
  upload_url = environment.upload_url;
  userid: any;
  binary_user = [];
  binary_users: any = [];
  binary_depth: number = 0;
  absolute_position: any = '';
  relative_position: any = '';
  placement_id: any = 0;
  msg_consumer_status = '';
  check_pay_button = false;
  selected_consumer_id = 0;
  selected_seller_id = 0;
  users:any = [];
  flg_tree: boolean = false;
  users_from_tree: any = [];
  users_from_tree_by_starter: any = [];
  user_to_tree: any = [];
  temp = {};
  productBySellerId: any = [];
  selected_product = {};
  selected_product_id: any = '';
  total_ordered_product: any = [];
  total_ordered_count = 0;
  total_item_amount = 0;
  qty = [];
  product_to_order = 2400;
  lcBalance = 0;
  uri = environment.backendUrl;
  payResult = 0;
  constructor(private storageService: StorageService,
              private binarySeller: BinarySellerService,
              private genealogyTreeService: GenealogyTreeService,
              private ccp: CountryCurrencyPriceService,
              private api: HttpService,
              public share: ShareService) {
    this.currentUser =  this.storageService.getUser()
  }

  ngOnInit(): void {
    if(this.currentUser) {
      this.userid = this.currentUser['id'];
      this.initBinaryUser(this.currentUser);
      this.getProducts('');
      this.getUsers();
      this.getCurrencyValue();
      this.getLcBalance();
      this.getUsersFromTree();
      this.getUsersFromTreeByStarter(this.userid);
    }
  }
  initBinaryUser(starter) {
    this.binary_user.push({'starter': starter}, {'layer1_left': []}, {'layer1_right': []}, {'layer2_left_1': []},
      {'layer2_left_2':[]}, {'layer2_right_1': []}, {'layer2_right_2': []},
      {'layer3_left_1': []}, {'layer3_left_2': []}, {'layer3_left_3': []}, {'layer3_left_4': []},
      {'layer3_right_1': []}, {'layer3_right_2': []}, {'layer3_right_3': []}, {'layer3_right_4': []});
  }
  getProducts(userid) {
    return this.binarySeller.getProducts('/binary-seller/getProducts', userid)
      .pipe(first()).subscribe(res=>{
        if(res) {
          this.productBySellerId = res;
          for(let product of this.productBySellerId) {
            this.qty[product['_id']] = 0;
          }
        }
      });
  }
  getUsers() {
    this.genealogyTreeService.getUsers().pipe().subscribe(res=>{this.users =res;});
  }
  getUserById(id) {
    for(let user of this.users) {
      if(user.userid == id) {
        return user;
      }
    }
  }
  async getCurrencyValue() {
    this.userInfo = await this.ccp.getUserInfo();
    // user country code
    this.cCode = this.userInfo['countryCode'];
    // get user country currency code
    this.curCode = this.currency[`${this.cCode}`];
    // get user country currency value
    this.currencyValue = await this.ccp.getCurrencyValue(this.curCode);
  }
  getLcBalance() {
    this.api.get(this.uri + '/getLcBalance/' + this.share.user.id).then((response: number) => {
      this.lcBalance = response['value'];
    });
  }
  getUsersFromTree() {
    this.genealogyTreeService.getUsersFromTree()
      .pipe().subscribe(res=> {
        this.users_from_tree = res;
        if(res) {
          this.checkTree();
        }
    })
  }
  getUsersFromTreeByStarter(userid) {
    this.users_from_tree_by_starter = [];
    if(userid) {
      this.genealogyTreeService.getUsersFromTreeByStarter(userid)
        .pipe().subscribe(res=> {
        if(res) {
          this.users_from_tree_by_starter = res;
          console.log('userid>>>>>>>>>>>2', userid, this.users_from_tree_by_starter)
          this.initTree();
        }
      })
    }
  }
  initTree() {
    for(let user of this.users_from_tree_by_starter) {
      if((user.upper_id == this.binary_user[0]['starter']['id'])||(user.upper_id == this.binary_user[0]['starter']['userid'])) {
        if(user.status == 'pass') {
          if(user.position == 'Left') {
            this.binary_user[1]['layer1_left'] = this.getUserById(user.user_id);
            this.temp = this.getDownTree(this.getUserById(user.user_id));
            if(this.temp) {
              if(this.temp['status'] == 'pass') {
                if(this.temp['position'] == 'Left') {
                  this.binary_user[3]['layer2_left_1'] = this.getUserById(this.temp['user_id']);
                  this.temp = {};
                  this.temp = this.getDownTree(this.binary_user[3]['layer2_left_1']);
                  if(this.temp) {
                    if(this.temp['status'] == 'pass') {
                      if(this.temp['position'] == 'Left') {
                        this.binary_user[7]['layer3_left_1'] =this.getUserById(this.temp['user_id']);
                      }
                      else {
                        this.binary_user[8]['layer3_left_2'] = this.getUserById(this.temp['user_id']);
                      }
                    }
                  }
                }
                else {
                  this.binary_user[4]['layer2_left_2'] = this.getUserById(this.temp['user_id']);
                  this.temp = {};
                  this.temp = this.getDownTree(this.binary_user[4]['layer2_left_2']);
                  if(this.temp) {
                    if(this.temp['status'] == 'pass') {
                      if(this.temp['position'] == 'Left') {
                        this.binary_user[9]['layer3_left_3'] =this.getUserById(this.temp['user_id']);
                      }
                      else {
                        this.binary_user[10]['layer3_left_4'] = this.getUserById(this.temp['user_id']);
                      }
                    }
                  }
                }
              }
            }
          }
          else{
            this.binary_user[2]['layer1_right'] = this.getUserById(user.user_id);
            this.temp = this.getDownTree(this.getUserById(user.user_id));
            if(this.temp) {
              if(this.temp['status'] == 'pass') {
                if(this.temp['position'] == 'Left') {
                  this.binary_user[5]['layer2_right_1'] = this.getUserById(this.temp['user_id']);
                  this.temp = {};
                  this.temp = this.getDownTree(this.binary_user[5]['layer2_Right_1']);
                  if(this.temp) {
                    if(this.temp['status'] == 'pass') {
                      if(this.temp['position'] == 'Right') {
                        this.binary_user[11]['layer3_right_1'] =this.getUserById(this.temp['user_id']);
                      }
                      else {
                        this.binary_user[12]['layer3_right_2'] = this.getUserById(this.temp['user_id']);
                      }
                    }
                  }
                }
                else {
                  this.binary_user[6]['layer2_right_2'] = this.getUserById(this.temp['user_id']);
                  this.temp = {};
                  this.temp = this.getDownTree(this.binary_user[6]['layer2_left_2']);
                  if(this.temp) {
                    if(this.temp['status'] == 'pass') {
                      if(this.temp['position'] == 'Left') {
                        this.binary_user[13]['layer3_right_3'] =this.getUserById(this.temp['user_id']);
                      }
                      else {
                        this.binary_user[14]['layer3_right_4'] = this.getUserById(this.temp['user_id']);
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
    console.log('binary user 1>>>>>>>>>>>>>>>>>>>>>>>>>>>>', this.binary_user);
  }

  initSubTree(subTree) {
    if(this.binary_depth) {
      this.getUsersFromTreeByStarter(subTree['userid']);
    } else{
      this.getUsersFromTreeByStarter(subTree['id'])
    }
    this.binary_user.forEach((value, index) => {
      for(let key in value)
        this.binary_user[index][key] = [];
    })
    this.binary_user[0]['starter'] =Object.assign({}, subTree);
    this.initTree();
  }
  showKidsTree(subTree) {
    const binary = [];
    this.binary_user.slice().forEach((item) => {
      binary.push(Object.assign({}, item));
    });
    this.binary_users.push(binary);
    this.binary_depth = this.binary_depth + 1;
    this.initSubTree(subTree);
  }
  getDownTree(upper_user) {
    if(upper_user) {
      for(let user of this.users_from_tree_by_starter) {
        if(user.upper_id == upper_user['userid']) {
          return user;
        }
      }
    }
  }
  //Check if the current logged in user exists and status is pass in tree model.
  checkTree() {
    for (let user of this.users_from_tree) {
      if(user.user_id == this.currentUser['id']) {
        if(user.status == 'pass') {
          this.flg_tree = true;
        }
      }
    }
  }
  goPrevious() {
    this.binary_depth = this.binary_depth - 1;
    if(this.binary_depth) {
      this.getUsersFromTreeByStarter(this.binary_users[this.binary_depth][0]['starter']['userid'])
    } else{
      this.getUsersFromTreeByStarter(this.binary_users[this.binary_depth][0]['starter']['id'])
    }
    this.initSubTree(this.binary_users[this.binary_depth][0]['starter']);
    this.binary_users.splice(this.binary_users.length-1, 1);
  }
  getUpperUser(binaryUser, absolute_position, relative_position) {
   this.placement_id = '';
   this.absolute_position = '';
   this.relative_position = '';
    for(let user of this.binary_user) {
      for(let key in user) {
        if(this.flg_tree&&key == binaryUser) {
          if(user[key]['id']) {
            this.placement_id = user[key]['id'];
          }
          else if(user[key]['userid']) {
            this.placement_id = user[key]['userid'];
          }
          if(this.placement_id) {
            this.absolute_position = absolute_position;
            this.relative_position = relative_position;
          }
        }
      }
    }
  }
  checkBinaryAvailable(event) {
    this.msg_consumer_status = '';
    const consumer_id = event.target.value;
    for(let user of this.users_from_tree) {
        if(user['user_id']) {
          if(user['user_id'].toString() == consumer_id) {
            this.msg_consumer_status = "Customer is not available.";
            this.selected_consumer_id = 0;
            return ;
          }
        }
    }
    if(this.users){
      for(let user of this.users) {
        if((user['userid'].toString() == consumer_id)) {
          this.msg_consumer_status = "Customer is  available.";
          this.selected_consumer_id = consumer_id;
        }
      }
      if(this.selected_consumer_id != consumer_id) {
        this.msg_consumer_status = "Customer is not registered user.";
        this.selected_consumer_id = 0;
        this.selected_seller_id = 0;
      }
    }
  }
  searchProductBySellerId(event) {
    this.selected_seller_id = event.target.value;
    this.getProducts(this.selected_seller_id);
  }
  addToCart(_id, product) {
    this.selected_product_id = _id;
    this.selected_product = product;
    this.total_ordered_count++;
    this.total_item_amount += this.qty[this.selected_product_id]*this.selected_product['market_price'];
    this.total_ordered_product.push({'starter_id': this.currentUser['id'], 'consumer_id': this.selected_consumer_id, 'seller_id': this.selected_seller_id,  'product_id': _id,'qty': this.qty[_id]});
    this.qty[_id] = 0;
    // if((this.total_item_amount-this.product_to_order>0)&&(this.lcBalance-this.total_item_amount/this.currencyValue>0)) {
    if((this.total_item_amount-this.product_to_order>0)) {
      this.check_pay_button = true;
    }
  }
  plusToCart(_id){
    this.qty[_id] = this.qty[_id] + 1;
  }
  subtractFromCart(_id){
    if(this.qty[_id]>0){
      this.qty[_id] = this.qty[_id] - 1;
      return;
    }
    this.qty[_id] = 0;
  }
  payNow() {
    this.payResult = this.lcBalance - this.total_item_amount/this.currencyValue;
    this.user_to_tree.push({user_id: this.selected_consumer_id, upper_id: this.placement_id, position: this.relative_position, seller_id: this.selected_seller_id, starter_id: this.userid})
    if(this.payResult>0) {
    }
    else{
      this.genealogyTreeService.createOrder(this.total_ordered_product)
        .pipe().subscribe(res => {
          if(res['status']) {
            this.check_pay_button = false;
          }
        });
      console.log('user to tree >>>>>>>>>>3', this.user_to_tree);
      this.genealogyTreeService.createTree(this.user_to_tree)
        .pipe().subscribe(res => {return res;});
    }
  }
}
